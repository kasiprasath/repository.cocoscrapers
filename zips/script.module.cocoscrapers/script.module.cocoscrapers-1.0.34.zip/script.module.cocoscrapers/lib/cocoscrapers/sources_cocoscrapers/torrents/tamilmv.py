# -*- coding: utf-8 -*-
"""
	CocoScrapers Project
	1TamilMV provider - scrapes torrent links from 1tamilmv.center
"""

import re
from urllib.parse import quote_plus, unquote_plus
from cocoscrapers.modules import cfscrape
from cocoscrapers.modules import client
from cocoscrapers.modules import source_utils
from cocoscrapers.modules import log_utils
from time import time


class source:
	priority = 5
	pack_capable = False
	hasMovies = True
	hasEpisodes = True
	def __init__(self):
		self.language = ['en', 'ta', 'te', 'hi', 'ml', 'kn']
		self.domains = ['1tamilmv.center', '1tamilmv.fi']
		self.base_link = "https://www.1tamilmv.center"
		self.search_link = '/index.php?/search/&q=%s&type=forums_topic&search_and_or=or&sortby=relevancy'
		self.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0'}
		self.item_totals = {'4K': 0, '1080p': 0, '720p': 0, 'SD': 0, 'CAM': 0}
		self.min_seeders = 0

	def sources(self, data, hostDict):
		sources = []
		if not data: return sources
		sources_append = sources.append
		try:
			startTime = time()
			scraper = cfscrape.create_scraper()
			aliases = data['aliases']
			year = data['year']
			if 'tvshowtitle' in data:
				title = data['tvshowtitle'].replace('&', 'and').replace('/', ' ').replace('$', 's')
				episode_title = data['title']
				hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode']))
				years = None
			else:
				title = data['title'].replace('&', 'and').replace('/', ' ').replace('$', 's')
				episode_title = None
				hdlr = year
				years = [str(int(year) - 1), str(year), str(int(year) + 1)]
			query = '%s %s' % (re.sub(r'[^A-Za-z0-9\s\.-]+', '', title), hdlr)
			url = '%s%s' % (self.base_link, self.search_link % quote_plus(query))
			# log_utils.log('1TAMILMV url = %s' % url)
			result = scraper.get(url, headers=self.headers, timeout=10).text
			if not result: return sources
			items = client.parseDOM(result, 'li', attrs={'class': r'ipsStreamItem\b[^"]*'})
			if not items: return sources
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except:
			source_utils.scraper_error('1TAMILMV')
			return sources

		topic_links = []
		for item in items:
			try:
				title_block = client.parseDOM(item, 'h2', attrs={'class': r'[^"]*ipsStreamItem_title[^"]*'})
				if not title_block: continue
				links = client.parseDOM(title_block[0], 'a', ret='href')
				if not links: continue
				topic_url = links[0].replace('&amp;', '&')
				topic_title = client.parseDOM(title_block[0], 'a')[0]
				topic_title = client.replaceHTMLCodes(topic_title).strip()
				topic_links.append((topic_url, topic_title))
			except:
				continue

		for topic_url, topic_title in topic_links[:8]:
			try:
				topic_result = scraper.get(topic_url, headers=self.headers, timeout=10).text
				if not topic_result: continue
				magnets = re.findall(r'href\s*=\s*["\'](magnet:\?xt=urn:btih:[^"\']+)["\']', topic_result, re.I)
				if not magnets: continue
				for magnet_url in magnets:
					try:
						magnet_url = magnet_url.replace('&amp;', '&')
						hash_match = re.search(r'btih:([a-f0-9]+)', magnet_url, re.I)
						if not hash_match: continue
						hash = hash_match.group(1)
						dn_match = re.search(r'[&?]dn=([^&]+)', magnet_url, re.I)
						if dn_match:
							name = unquote_plus(dn_match.group(1))
							name = re.sub(r'^www\.1TamilMV\.\w+\s*-\s*', '', name, flags=re.I)
							name = name.replace('.mkv', '').replace('.mp4', '').replace('.avi', '')
						else:
							name = topic_title
						name = source_utils.clean_name(name)

						if not source_utils.check_title(title, aliases, name, hdlr, year, years if not episode_title else None): continue
						name_info = source_utils.info_from_name(name, title, year, hdlr, episode_title)
						if source_utils.remove_lang(name_info, check_foreign_audio): continue
						if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue

						if not episode_title:
							ep_strings = [r'[.-]s\d{2}e\d{2}([.-]?)', r'[.-]s\d{2}([.-]?)', r'[.-]season[.-]?\d{1,2}[.-]?']
							name_lower = name.lower()
							if any(re.search(item, name_lower) for item in ep_strings): continue

						url = magnet_url.split('&tr=')[0].replace(' ', '.')
						quality, info = source_utils.get_release_quality(name_info, url)
						try:
							size_match = re.search(r'(\d+(?:\.\d+)?)\s*(GB|MB)', name, re.I)
							if size_match:
								size_val = float(size_match.group(1))
								size_unit = size_match.group(2).upper()
								if size_unit == 'MB':
									dsize = size_val / 1024.0
								else:
									dsize = size_val
								isize = '%.2f GB' % dsize
								info.insert(0, isize)
							else:
								dsize = 0
						except:
							dsize = 0
						info = ' | '.join(info)

						sources_append({'provider': '1tamilmv', 'source': 'torrent', 'seeders': 0, 'hash': hash, 'name': name, 'name_info': name_info,
							'quality': quality, 'language': 'en', 'url': url, 'info': info, 'direct': False, 'debridonly': True, 'size': dsize})
						self.item_totals[quality] += 1
					except:
						source_utils.scraper_error('1TAMILMV')
			except:
				source_utils.scraper_error('1TAMILMV')
		logged = False
		for quality in self.item_totals:
			if self.item_totals[quality] > 0:
				log_utils.log('#STATS - 1TAMILMV found {0:2.0f} {1}'.format(self.item_totals[quality], quality))
				logged = True
		if not logged: log_utils.log('#STATS - 1TAMILMV found nothing')
		endTime = time()
		log_utils.log('#STATS - 1TAMILMV took %.2f seconds' % (endTime - startTime))
		return sources
